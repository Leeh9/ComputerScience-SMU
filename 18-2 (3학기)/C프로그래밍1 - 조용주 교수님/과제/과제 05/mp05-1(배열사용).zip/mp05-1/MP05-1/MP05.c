#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void FillInArray(int* a, int len)
{
	int i;
	for (i = 0; i < len; i++) {
		a[i] = rand() % 30 + 1;
	}
}

void PrintArray(int* a, int len)
{
	int i;
	printf("Index\tValue\tHistogram\n");
	printf("-------------------------------------------------------------------\n");
	for (i = 0; i < len; i++) {
		int j;
		printf("%d\t%d\t", i, a[i]);
		for (j = 0; j < a[i]; j++)
			printf("*");
		printf("\n");
	}
}

void CalcAndCount(int* a, int len, 
	         double* average, int* count1to10,
			 int* count11to20, int* count21to30)
{
	int i;
	int sum = 0;

	for (i = 0; i < len; i++) {
		sum += a[i];
		if (a[i] >= 0 && a[i] <= 10) {
			(*count1to10)++;
		}
		else if (a[i] >= 11 && a[i] <= 20) {
			(*count11to20)++;
		}
		else {
			(*count21to30)++;
		}
	}
	*average = (double)sum / len;
}

void PrintAverageAndDistribution(double average, int count1to10,
	      int count11to20, int count21to30)
{
	printf("Average: %lf\n", average);
	printf("Distribution\n");
	printf("1-10:\t%d\n", count1to10);
	printf("11-20:\t%d\n", count11to20);
	printf("21-30:\t%d\n", count21to30);
}

#define SIZE 50

int main(void)
{
	int a[SIZE];

	srand(time(NULL));
	FillInArray(a, SIZE);
	PrintArray(a, SIZE);
	double average;
	int count1 = 0, count2 = 0, count3 = 0;

	CalcAndCount(a, SIZE, &average, &count1, 
		         &count2, &count3);

	PrintAverageAndDistribution(average, count1, count2, count3);
	return 0;
}