#include <math.h>
#include <stdio.h>
int main(void) 
{
	int n;
	double d;

	scanf("%d", &n);
	d = sqrt(n);
	printf("sqrt(%d) = %lf\n", n, d);
	return 0;
}
