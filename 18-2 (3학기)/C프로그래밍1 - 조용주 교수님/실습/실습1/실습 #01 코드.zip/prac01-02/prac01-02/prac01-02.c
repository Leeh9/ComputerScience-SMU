#include <stdio.h>

int main()
{
	double n1;
	double n2;
	double n3;
	double result = 0.0;

	scanf("%lf %lf %lf", &n1, &n2, &n3);
//	printf("%lf %lf %lf\n", n1, n2, n3);
	result = n1 * n2 + n3;
	printf("%lf x %lf + %lf = %lf", n1, n2, n3, result);
	return 0;
}